function checkPassword() {
    const message = document.getElementById('message');
    message.textContent = 'Invalid code';
}
